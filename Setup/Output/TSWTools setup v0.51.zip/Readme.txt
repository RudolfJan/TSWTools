TSWTools

TSWTools is a toolkit for Train Simulator World.
At present it has limited functionality, but this will increase over time.
After installation, please set up the program options before trying to do anything else.

Check out http:/www.hollandhiking.nl/trainsimulator for other tools and documentation for TSW and TrainSimulator.

Installation instructions:
- Use the installer to install all tools
- You will need to download additional free tools
- Make sure to set all required options
-If you do not want to use, the default data location, you may need to move some files manually

See the manual for details.

Version history:

Version 0.51:
- Bug fixes
- Addes Cab sway setting

Version 0.5
- Bug fixes
- Improved behaviour on small screens

Version 0.4:
- Fixed some bugs
- Pak installer
- Livery sets
- Radio stations collection

Version 0.3
- New interface
- Livery manager
- Settings tool

Version 0.21:
- Fixed annoying bug in options settings
- Unpacking pak files now works with multiple threads
- Busy indicator while unpacking
- You now can unpack a single .pak file

Version 0.2:
- Unpack function improved
- Screenshotmanager improved
- New function to create multiple settings files
- Game launcher

Version 0.1
First public alpha version